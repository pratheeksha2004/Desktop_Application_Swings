/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package libraryman;
public class Libraryman {
    public static void main(String[] args) {
        loginpage loginframe = new loginpage();
        loginframe.setVisible(true);
    
        loginframe.pack();
        loginframe.setLocationRelativeTo(null);
        
    }
    
}
