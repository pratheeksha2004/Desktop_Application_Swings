
package libraryman;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

 
public class LibrarianLAO {
     public static boolean validate(String enteredUsername, String enteredPassword) {
        try (Connection connection = DB.getConnection()) {
            String query = "SELECT password FROM adminadd WHERE name = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, enteredUsername);

            ResultSet result = statement.executeQuery();

            if (result.next()) {
                String storedPassword = result.getString("password");
               if (storedPassword.equals(enteredPassword)) {
                    return true; // Passwords match
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false; // Return false if validation fails
    }

}




   