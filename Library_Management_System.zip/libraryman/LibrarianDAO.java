
package libraryman;
import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LibrarianDAO {
 
      public static boolean insertBook(int book_no, String name, String author, int quantity) {
        try (Connection connection = DB.getConnection()) {
            String query = "INSERT INTO AddBooks (book_no,name,author,quantity) VALUES (?, ?, ?,?)";
            PreparedStatement statement = connection.prepareStatement(query);
            
statement.setInt(1, book_no);
statement.setString(2, name);
statement.setString(3, author); // Assuming 'author' is a string
statement.setInt(4, quantity);


            int rowsInserted = statement.executeUpdate();

            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
      
      public static boolean insertLibrarian(String name, String password, String email, String address, String city, Long contact) {
        String query = "INSERT INTO adminadd(name, password, email, adress1, city, contact) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, name);
            statement.setString(2, password);
            statement.setString(3, email);
            statement.setString(4, address);
            statement.setString(5, city);
            statement.setLong(6, contact);

            int rowsInserted = statement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
      
     public static List<Librarian> getAllLibrarians() {
    List<Librarian> librarians = new ArrayList<>();
    try (Connection connection = DB.getConnection();
         Statement statement = connection.createStatement();
        
            ResultSet resultSet = statement.executeQuery("SELECT * FROM adminadd")) {
        int rowCount = 0;
        while (resultSet.next()) {
             rowCount++;
            // Retrieve data from the ResultSet and create Librarian objects
          String name = resultSet.getString("name");
        String password = resultSet.getString("password");
        String email = resultSet.getString("email");
        String adress1 = resultSet.getString("adress1");
        String city = resultSet.getString("city");
        long contact = resultSet.getLong("contact");
System.out.println("Name: " + name + ", Password: " + password + ", Email: " + email + ", Address: " + adress1 + ", City: " + city + ", Contact: " + contact);

            // Create a Librarian object with the retrieved data
            Librarian librarian = new Librarian(name, password, email, adress1, city, contact);
            librarians.add(librarian); // Add to the list
        }
        System.out.println("Number of rows retrieved: " + rowCount);
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return librarians;
}

public static boolean isStudentIdValid(int id) {
    try (Connection connection = DB.getConnection()) {
        String query = "SELECT * FROM colmanage WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setInt(1, id);

        ResultSet resultSet = preparedStatement.executeQuery();

        return resultSet.next(); // If there's a match, it's a valid student ID.
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    } 
}

public static boolean issueBook(int bookNumber, int studentId, String studentName, long studentContact, String bookName) {
    Connection connection = null;
    PreparedStatement preparedStatement = null;

    try {
        connection = DB.getConnection();
        String query = "INSERT INTO stuissue (book_no, stu_id, stu_name, stu_contact, book_name) VALUES (?, ?, ?, ?, ?)";
        preparedStatement = connection.prepareStatement(query);

        // Set the values for the parameters
        preparedStatement.setInt(1, bookNumber);
        preparedStatement.setInt(2, studentId);
        preparedStatement.setString(3, studentName);
        preparedStatement.setLong(4, studentContact);
        preparedStatement.setString(5, bookName);

        // Execute the query
        int rowsAffected = preparedStatement.executeUpdate();

        // Return true if at least one row was affected (successful insertion)
        return rowsAffected > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    } finally {
        // Close resources in the finally block to ensure they are closed even if an exception occurs
        try {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

}
