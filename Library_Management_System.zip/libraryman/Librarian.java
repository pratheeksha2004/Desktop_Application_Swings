
package libraryman;
public class Librarian {
    private String name;
    private String password;
    private String email;
    private String adress1; 
    private String city;
    private long contact;

    public Librarian(String name, String password, String email, String adress1, String city, long contact) {
        this.name = name;
        this.password = password;
        this.email = email;
        this.adress1 = adress1;
        this.city = city;
        this.contact = contact;
    }

    public String getname() {
        return name;
    }

    public String getpassword() {
        return password;
    }

    public String getemail() {
        return email;
    }

    public String getadress1() {
        return adress1;
    }

    public String getcity() {
        return city;
    }

    public long getcontact() {
        return contact;
    }

    // Add setters if needed

    @Override
    public String toString() {
        return "Librarian{" +
               "name='" + name + '\'' +
               ", password='" + password + '\'' +
               ", email='" + email + '\'' +
               ", adress1='" + adress1 + '\'' +
               ", city='" + city + '\'' +
               ", contact='" + contact + '\'' +
               '}';
    }

    
}
